// routes/games.js
const gamesRouter = require("express").Router(); // Создали роутер
//const { deleteGame, sendAllGames } = require("../controllers/games")
const { getAllGames } = require("../middlewares/games")
const { deleteGame, sendAllGames,addGameController } = require("../controllers/games")

gamesRouter.get("/games", getAllGames, sendAllGames)
gamesRouter.delete("/games/:id", getAllGames, deleteGame);
gamesRouter.post("/games", getAllGames, addGameController);

module.exports = gamesRouter;